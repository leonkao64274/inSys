//package com.hitrust.emv.threeds.threedsserver.core.base.enums;
package com.hitrust.emv.threeds.threedsserver.admin.controller;

public enum ThreeDSData {

	/* ==========
	 * 	Class
	 * ==========
	 */
	// 驗證交易請求
	THREEDS_REQUEST,
	// 1.0 驗證交易
	THREEDS_RECORD,
	// 2.0 驗證交易
	THREEDS_TRANS,

	/* ==========
	 * 	Field
	 * ==========
	 */
	// 3DS交易序號
	THREEDS_TRANS_ID,
	// 持卡人帳戶號碼(ex: 信用卡號)
	ACCT_NUMBER

}
