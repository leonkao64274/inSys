/*
 * @(#)AdminUserForm.java
 *
 * Copyright (c) 2017 HiTRUST Incorporated.
 * All rights reserved.
 * 
 * Description:
 *      網際威信 EMV 3DS 系統 - 3DS-Server後台管理模組 "群組使用者管理" 新增、修改用表單類別
 *
 * Modify History:
 * v1.00, 2017/10/20, JasonWu
 *   1) 增加加密後密碼欄位 
 */
package com.hitrust.emv.threeds.threedsserver.admin.controller;

import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import com.hitrust.emv.threeds.threedsserver.core.bean.AdminUser;

/**
 * 網際威信 EMV 3DS 系統 - 3DS-Server後台管理模組      '群組使用者管理' 新增、修改用表單類別
 * 
 * @author JasonWu
 */
public class AdminUserForm extends AdminUser{
	
	private static final long serialVersionUID = 1L;
	
	/**
     * 確認密碼
     */
//	@NotEmpty
    @Size(min = 6, max = 12)
	@Pattern(regexp = "^[A-Za-z0-9]+$",message="{passwords.format.is.wrong}")
    private String cnfrPassword;

	public AdminUserForm() {
		super();
	}
	
	public AdminUserForm(String cnfrPassword) {
		super();
		this.cnfrPassword = cnfrPassword;
	}
	
	//確認密碼
	public String getCnfrPassword() {
		return cnfrPassword;
	}

	public void setCnfrPassword(String cnfrPassword) {
		this.cnfrPassword = cnfrPassword;
	}
	
	
    /**
     * 加密後的密碼<br/>
     * 企業規則 = sha1(account + password)
     */
    private String encryptPassword;

	public String getEncryptPassword() {
		return encryptPassword;
	}

	public void setEncryptPassword(String encryptPassword) {
		this.encryptPassword = encryptPassword;
	}    
	
}
