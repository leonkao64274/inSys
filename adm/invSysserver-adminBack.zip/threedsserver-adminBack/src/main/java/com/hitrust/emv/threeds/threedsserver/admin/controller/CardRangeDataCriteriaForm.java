/*
 * @(#)CardRangeDataCriteriaForm.java
 *
 * Copyright (c) 2018 HiTRUST Incorporated.
 * All rights reserved.
 * 
 * Description:
 *      網際威信 EMV 3DS 系統 - 3DS Server 後台管理 "卡 BIN 範圍" 查詢作業表單類別
 *
 * Modify History:
 * v1.00, 2019/05/18, Kevin Wang
 *   1) First release
 *
 */
package com.hitrust.emv.threeds.threedsserver.admin.controller;

import java.io.Serializable;
import javax.validation.constraints.Size;

/**
 * 網際威信 EMV 3DS 系統 - 3DS Server 後台管理 "卡 BIN 範圍" 查詢作業表單類別
 * 
 * @author KevinWang
 */
public class CardRangeDataCriteriaForm implements Serializable {
    
	/**
	 * 查詢條件(1)-卡組織
	 */
    @Size(max = 1)
	private String criteriaCardScheme;

    public String getCriteriaCardScheme() {
        return criteriaCardScheme;
    }

    public void setCriteriaCardScheme(String criteriaCardScheme) {
        this.criteriaCardScheme = criteriaCardScheme;
    }
    
    /**
     * 查詢條件(2)-卡號
     */
    @Size(max = 19)
    private String criteriaAcctNumber;

    public String getCriteriaAcctNumber() {
        return criteriaAcctNumber;
    }

    public void setCriteriaAcctNumber(String criteriaAcctNumber) {
        this.criteriaAcctNumber = criteriaAcctNumber;
    }    
    
    /**
     * 指定分頁查詢頁次
     */
    private Integer pageNumber;

    public Integer getPageNumber() {
        if (pageNumber == null) {
            return 0;
        }
        return pageNumber;
    }

    public void setPageNumber(Integer pageNumber) {
        this.pageNumber = pageNumber;
    }
    
}
