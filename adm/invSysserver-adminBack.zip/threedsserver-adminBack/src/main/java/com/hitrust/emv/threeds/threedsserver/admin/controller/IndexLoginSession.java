/*
 * @(#)IndexLoginSession.java
 *
 * Copyright (c) 2017 HiTRUST Incorporated.
 * All rights reserved.
 * 
 * Description:
 *      網際威信 EMV 3DS 系統 -3DS Server 後台管理 的用戶登錄用 Session 級屬性記錄元件類。
 *
 * Modify History:
 * v1.00, 2017/10/16, JasonWu
 */
package com.hitrust.emv.threeds.threedsserver.admin.controller;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

import com.hitrust.emv.threeds.threedsserver.core.bean.AdminUser;
import com.hitrust.emv.threeds.threedsserver.core.bean.LoginSessionKey;

import java.io.Serializable;
import java.util.List;
import java.util.Locale;

/**
 * 網際威信 EMV 3DS 系統 - 3DS Server 後台管理 的用戶登錄用 Session 級屬性記錄元件類。
 * 
 * @author JasonWu
 */
@Component
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS, value = "session")
public class IndexLoginSession implements Serializable{
	
	private static final long serialVersionUID = 1L;

	/**
	 * 用戶登錄訊息類。
	 */
	private AdminUser adminUser = null;
    
    /**
     * 被授權的功能項目代碼
     */
    private List<String> grantedAccessIdList;
    
    /**
     * 語言國別代碼
     */
    private Locale locale;
    
    /**
     * 登入紀錄
     */
    private LoginSessionKey loginSessionKey;
	
    //=================================================
    // constructors
    //=================================================
    
    /**
     * 預設建構子
     */
	public IndexLoginSession() {}

    //=================================================
    // getter & setter
    //=================================================

	public AdminUser getAdminUser() {
		return adminUser;
	}

	public void setAdminUser(AdminUser adminUser) {
		this.adminUser = adminUser;
	}

    public List<String> getGrantedAccessIdList() {
        return grantedAccessIdList;
    }

    public void setGrantedAccessIdList(List<String> grantedAccessIdList) {
        this.grantedAccessIdList = grantedAccessIdList;
    }

	public Locale getLocale() {
		return locale;
	}

	public void setLocale(Locale locale) {
		this.locale = locale;
	}

	public LoginSessionKey getLoginSessionKey() {
		return loginSessionKey;
	}

	public void setLoginSessionKey(LoginSessionKey loginSessionKey) {
		this.loginSessionKey = loginSessionKey;
	}
    
}
