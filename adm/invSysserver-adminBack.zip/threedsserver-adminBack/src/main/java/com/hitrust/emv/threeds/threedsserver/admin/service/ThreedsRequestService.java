//package com.hitrust.emv.threeds.threedsserver.core.base.service;
package com.hitrust.emv.threeds.threedsserver.admin.service;

import com.hitrust.emv.threeds.threedsserver.admin.bean.ThreedsRequest;
import com.hitrust.emv.threeds.threedsserver.admin.exception.ThreeDSDataNotFoundException;
//import com.hitrust.emv.threeds.threedsserver.core.base.bean.ThreedsRequest;
//import com.hitrust.emv.threeds.threedsserver.core.base.exception.ThreeDSDataNotFoundException;
import com.hitrust.emv.threeds.threedsserver.core.service.GenericEntityService;

public interface ThreedsRequestService extends GenericEntityService<ThreedsRequest, Long> {

	/**
	 * 依據3DS Server交易序號查詢對應的3DS驗證請求資料
	 *
	 * @param threeDSServerTransID 3DS Server交易序號
	 * @return 對應的3DS驗證請求資料
	 * @throws ThreeDSDataNotFoundException 無法取得對應資料時拋出
	 */
	public ThreedsRequest findByThreeDSServerTransID(String threeDSServerTransID) throws ThreeDSDataNotFoundException;

	/**
	 * 依據oid值字串查詢對應的3DS驗證請求資料
	 *
	 * @param oid oid字串
	 * @return 對應的3DS驗證請求資料
	 * @throws ThreeDSDataNotFoundException 無法取得對應資料時拋出
	 */
	public ThreedsRequest findByOid(String oid) throws ThreeDSDataNotFoundException;
}
