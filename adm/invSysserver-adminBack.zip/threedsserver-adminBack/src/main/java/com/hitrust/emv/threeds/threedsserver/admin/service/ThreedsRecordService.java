//package com.hitrust.emv.threeds.threedsserver.core.base.service;
package com.hitrust.emv.threeds.threedsserver.admin.service;

import com.hitrust.emv.threeds.threedsserver.admin.bean.ThreedsRecord;
import com.hitrust.emv.threeds.threedsserver.admin.exception.ThreeDSDataNotFoundException;
//import com.hitrust.emv.threeds.threedsserver.core.base.bean.ThreedsRecord;
//import com.hitrust.emv.threeds.threedsserver.core.base.exception.ThreeDSDataNotFoundException;
import com.hitrust.emv.threeds.threedsserver.core.service.GenericEntityService;

public interface ThreedsRecordService extends GenericEntityService<ThreedsRecord, Long> {

	/**
	 * 依據3DS交易序號查詢對應的3DS 1.0驗證交易資料
	 *
	 * @param threeDSTransID 3DS交易序號
	 * @return 對應的3DS 1.0驗證交易資料
	 * @throws ThreeDSDataNotFoundException 無法取得對應資料時拋出
	 */
	public ThreedsRecord findByThreeDSTransID(String threeDSTransID) throws ThreeDSDataNotFoundException;

}
