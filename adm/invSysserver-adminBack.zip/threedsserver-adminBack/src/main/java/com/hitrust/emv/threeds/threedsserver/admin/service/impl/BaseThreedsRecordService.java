//package com.hitrust.emv.threeds.threedsserver.core.base.service.impl;
package com.hitrust.emv.threeds.threedsserver.admin.service.impl;

//import com.hitrust.emv.threeds.threedsserver.core.base.bean.ThreedsRecord;
//import com.hitrust.emv.threeds.threedsserver.core.base.dao.ThreedsRecordDao;
//import com.hitrust.emv.threeds.threedsserver.core.base.enums.ThreeDSData;
//import com.hitrust.emv.threeds.threedsserver.core.base.exception.ThreeDSDataNotFoundException;
//import com.hitrust.emv.threeds.threedsserver.core.base.service.ThreedsRecordService;
//import com.hitrust.emv.threeds.threedsserver.core.base.util.DateTimeUtil;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.hitrust.emv.threeds.threedsserver.admin.bean.ThreedsRecord;
import com.hitrust.emv.threeds.threedsserver.admin.util.DateTimeUtil;
import com.hitrust.emv.threeds.threedsserver.admin.controller.ThreeDSData;

import com.hitrust.emv.threeds.threedsserver.admin.dao.ThreedsRecordDao;
import com.hitrust.emv.threeds.threedsserver.admin.exception.ThreeDSDataNotFoundException;
import com.hitrust.emv.threeds.threedsserver.admin.service.ThreedsRecordService;

@Service
@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED, readOnly = true, rollbackFor = {Exception.class})
public class BaseThreedsRecordService implements ThreedsRecordService {

	private static final Logger logger = LoggerFactory.getLogger(BaseThreedsRequestService.class);

	@Autowired
	private ThreedsRecordDao threedsRecordDao;

	@Override
	@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED, readOnly = false, rollbackFor = {Exception.class})
	public <S extends ThreedsRecord> void save(S s) {
		// 設定資料建立、異動時間
		s.setCreateDate(DateTimeUtil.getCurrentDate());
		s.setCreateTime(DateTimeUtil.getCurrentTime());
		s.setUpdateDate(DateTimeUtil.getCurrentDate());
		s.setUpdateTime(DateTimeUtil.getCurrentTime());
		// 新增資料數據
		this.threedsRecordDao.save(s);

		// 產生3DS 1.0交易序號
		s.setThreeDSTransID(this.generateThreeDSTransID(s.getOid().toString()));
	}

	private String generateThreeDSTransID(String oid) {
		StringBuilder sb = new StringBuilder(DateTimeUtil.getCurrentDateTime());
		if (oid.length() < 6)
			sb.append(StringUtils.leftPad(oid, 6, "0"));
		else
			sb.append(StringUtils.right(oid, 6));
		return sb.toString();
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED, readOnly = false, rollbackFor = {Exception.class})
	public <S extends ThreedsRecord> void update(S s) {
		// 設定資料異動時間
		s.setUpdateDate(DateTimeUtil.getCurrentDate());
		s.setUpdateTime(DateTimeUtil.getCurrentTime());
		// 更新資料數據
		this.threedsRecordDao.save(s);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED, readOnly = false, rollbackFor = {Exception.class})
	public void delete(Long id) {
		// 依據主鍵值刪除資料數據
		this.threedsRecordDao.delete(id);
	}

	@Override
	public ThreedsRecord findById(Long id) {
		// 依據主鍵值查詢資料數據
		return this.threedsRecordDao.findOne(id);
	}

	@Override
	public ThreedsRecord findByThreeDSTransID(String threeDSTransID) throws ThreeDSDataNotFoundException {
		ThreedsRecord threedsRecord = null;
		try {
			threedsRecord = this.threedsRecordDao.findByThreeDSTransID(threeDSTransID);

		} catch (Exception e) {
			logger.error("exception when finding threedsRecord by threeDSTransId", e);
			throw new ThreeDSDataNotFoundException(ThreeDSData.THREEDS_RECORD);
		}

		// 查無對應資料時回傳null
		if (threedsRecord == null) {
			logger.debug("threedsRecord not found by threeDSTransId = " + threeDSTransID);
			throw new ThreeDSDataNotFoundException("threedsRecord not found by threeDSTransId", ThreeDSData.THREEDS_RECORD);
		}

		return threedsRecord;
	}

}
