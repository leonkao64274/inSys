/* Bean
 *
 * @(#)MerchantInfo.java
 *
 * Copyright (c) 2020 HiTRUST Incorporated.
 * All rights reserved.
 * 
 * Description:
 *      網際威信 EMV 3DS 系統 - 目錄服務器設定 Entity 類別
 *
 *
 */
//package com.hitrust.emv.threeds.threedsserver.core.bean;
package com.hitrust.emv.threeds.threedsserver.admin.bean;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotEmpty;

import com.hitrust.emv.threeds.threedsserver.core.bean.BaseBean;

/**
 * 網際威信 EMV 3DS 系統 - 目錄服務器設定 Entity 類別
 * 
 * @author Abner Chang
 */
@Entity
@Table(name = "T_MERCHANT_INFO")
public class MerchantInfo extends BaseBean {
    
    private final static long serialVersionUID = 1L;
    
	/**
     * 商店ID 
     */
	@NotEmpty
    @Column(name = "ACQUIRER_MERCHANT_ID", length = 35, nullable = false, unique = true)
    private String acquirerMerchantId;
    
    /**
     * 商家密碼
     */
	@NotEmpty
    @Column(name = "ACQUIRER_MERCHANT_PWD", length = 16, nullable = false)
    private String acquiererMerchantPwd;
    
    /**
     * 商店類別代碼
     */
	@NotEmpty
    @Column(name = "MCC", length = 4, nullable = false)
    private String mcc;
    
    /**
     * 商店國家代碼
     */
	@NotEmpty
    @Column(name = "MERCHANT_COUNTRY_CODE", length = 3, nullable = false)
    private String merchantCountryCode;
    
    /**
     * 商店名稱
     */
	@NotEmpty
    @Column(name = "MERCHANT_NAME", length = 40, nullable = false)
    private String merchantName;
    
    /**
     * 幣別代碼
     */
	@NotEmpty
    @Column(name = "PURCHASE_CURRENCY", length = 3, nullable = false)
    private String purchaseCurrency;
    
    /**
     * 貨幣指數
     */
	@NotEmpty
    @Column(name = "PURCHASE_EXPONENT", length = 1, nullable = false)
    private String purchaseExponent;
    
    /**
     * 3DS URL
     */
	@NotEmpty
    @Column(name = "THREEDS_REQUESTOR_URL", length = 2048, nullable = false)
    private String threedsRequestorUrl;
    
    /**
     * 商店狀態 
        A = Activate
        L = Lock
     */
	@NotEmpty
    @Size(max = 1)
    @Column(name = "MER_STATUS", length = 1, nullable = false)
    private String merStatus;

    //=================================================
    // constructors
    //=================================================
    
    public MerchantInfo() {
        super();
    }
    
    //=================================================
    // getter & setter
    //=================================================

    public String getAcquirerMerchantId() {
        return acquirerMerchantId;
    }

    public void setAcquirerMerchantId(String acquirerMerchantId) {
        this.acquirerMerchantId = acquirerMerchantId;
    }

    public String getAcquiererMerchantPwd() {
        return acquiererMerchantPwd;
    }

    public void setAcquiererMerchantPwd(String acquiererMerchantPwd) {
        this.acquiererMerchantPwd = acquiererMerchantPwd;
    }

    public String getMcc() {
        return mcc;
    }

    public void setMcc(String mcc) {
        this.mcc = mcc;
    }

    public String getMerchantCountryCode() {
        return merchantCountryCode;
    }
    
    public void setMerchantCountryCode(String merchantCountryCode) {
        this.merchantCountryCode = merchantCountryCode;
    }

    public String getMerchantName() {
        return merchantName;
    }

    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }

    public String getPurchaseCurrency() {
        return purchaseCurrency;
    }

    public void setPurchaseCurrency(String purchaseCurrency) {
        this.purchaseCurrency = purchaseCurrency;
    }

    public String getPurchaseExponent() {
        return purchaseExponent;
    }

    public void setPurchaseExponent(String purchaseExponent) {
        this.purchaseExponent = purchaseExponent;
    }

    public String getThreedsRequestorUrl() {
        return threedsRequestorUrl;
    }

    public void setThreedsRequestorUrl(String threedsRequestorUrl) {
        this.threedsRequestorUrl = threedsRequestorUrl;
    }

    public String getMerStatus() {
        return merStatus;
    }

    public void setMerStatus(String merStatus) {
        this.merStatus = merStatus;
    }
}
