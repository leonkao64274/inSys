/*
 * @(#)ErrorController.java
 *
 * Copyright (c) 2017 HiTRUST Incorporated.
 * All rights reserved.
 * 
 * Description:
 *      網際威信 EMV 3DS 系統 - 3DS Server 後台管理  "錯誤網頁 " 控制器類別
 *
 * Modify History:
 * v1.00, 2017/08/18, JasonWu
 *   1) First release
 *
 */
package com.hitrust.emv.threeds.threedsserver.admin.controller;
 
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory; 
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping; 

/**
 * 網際威信 EMV 3DS 系統 - 3DS Server 後台管理  "錯誤網頁" 控制器類別
 * 
 * @author JasonWu
 */
@Controller
public class ErrorController {
    
    private static final Logger logger = LoggerFactory.getLogger(ErrorController.class);

    @GetMapping("/400")
    public String badRequest(HttpServletRequest request) {
        return "error/400";
    }
    @GetMapping("/404")
    public String notFound(HttpServletRequest request) {
        return "error/404";
    }
    @GetMapping("/405")
    public String methodNotAllowed(HttpServletRequest request) {
        return "error/405";
    }
    @GetMapping("/500")
    public String serverError(HttpServletRequest request) {
        return "error/500";
    }
}
