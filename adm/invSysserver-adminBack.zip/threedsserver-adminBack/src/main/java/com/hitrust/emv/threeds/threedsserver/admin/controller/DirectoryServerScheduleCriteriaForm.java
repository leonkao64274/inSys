/*
 * @(#)DirectoryServerScheduleCriteriaForm.java
 *
 * Copyright (c) 2017 HiTRUST Incorporated.
 * All rights reserved.
 * 
 * Description:
 *      網際威信 EMV 3DS 系統 - 3DS Server 後台管理 "卡段下載設定" 查詢作業表單類別
 *
 * Modify History:
 * v1.00, 2017/07/31, JasonWu
 *   1) First release
 *
 */
package com.hitrust.emv.threeds.threedsserver.admin.controller;

import java.io.Serializable;

public class DirectoryServerScheduleCriteriaForm implements Serializable{
	
	private static final long serialVersionUID = 1L;


	/**
	 * 查詢條件(1)-卡組織
	 */
	private String criteriaCardScheme;

	public String getCriteriaCardScheme() {
		return criteriaCardScheme;
	}

	public void setCriteriaCardScheme(String criteriaCardScheme) {
		this.criteriaCardScheme = criteriaCardScheme;
	}
	 
    /**
     * 指定分頁查詢頁次
     */
    private Integer pageNumber;

    public Integer getPageNumber() {
        if (pageNumber == null) {
            return 0;
        }
        return pageNumber;
    }

    public void setPageNumber(Integer pageNumber) {
        this.pageNumber = pageNumber;
    }
    
    
}
