/*
 * @(#)InvalidAccessException.java
 *
 * Copyright (c) 2017 HiTRUST Incorporated.
 * All rights reserved.
 * 
 * Description:
 *      網際威信 EMV 3DS 系統 - 3DS Server 後台管理系統 "異常權限操作" 異常類別
 *
 * Modify History:
 * v1.00, 2017/09/06, Kevin Wang
 *   1) First release
 */
package com.hitrust.emv.threeds.threedsserver.admin.exception;

/**
 * 網際威信 EMV 3DS 系統 - 3DS Server 後台管理系統 "異常權限操作" 異常類別 
 * 
 * @author KevinWang
 */
public class InvalidAccessException extends RuntimeException {

    public InvalidAccessException(String message) {
        super(message);
    }

    public InvalidAccessException(String message, Throwable cause) {
        super(message, cause);
    }

    public InvalidAccessException(Throwable cause) {
        super(cause);
    }
    
}
