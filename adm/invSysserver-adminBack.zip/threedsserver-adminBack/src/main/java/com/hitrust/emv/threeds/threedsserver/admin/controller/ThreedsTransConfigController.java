/*
 * @(#)ThreedsTransConfigController.java
 *
 * Copyright (c) 2017 HiTRUST Incorporated.
 * All rights reserved.
 * 
 * Description:
 *      網際威信 EMV 3DS 系統 - 3DS-Server後台管理模組/3DS 交易參數設定 Controller(控制器)。
 *
 * Modify History:
 * v1.00, 2017/07/11, Kevin Wang
 *   1) First release
 * v1.00, 2017/08/01, Milo Gao
 *   2) 接手開發。
 * v1.01, 2017/12/26, Bob Shih
 *   1) 修正資料未正確儲存。
 */
package com.hitrust.emv.threeds.threedsserver.admin.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.hitrust.emv.threeds.threedsserver.admin.aspect.AcessRightCheck;
import com.hitrust.emv.threeds.threedsserver.admin.log.DoOperationLog;
import com.hitrust.emv.threeds.threedsserver.admin.log.LogContextHolder;
import com.hitrust.emv.threeds.threedsserver.admin.util.WebKeyConst;
import com.hitrust.emv.threeds.threedsserver.core.bean.SysCode;
import com.hitrust.emv.threeds.threedsserver.core.bean.ThreedsTransConfig;
import com.hitrust.emv.threeds.threedsserver.core.exception.ResourceNotFoundException;
import com.hitrust.emv.threeds.threedsserver.core.service.SysCodeService;
import com.hitrust.emv.threeds.threedsserver.core.service.ThreedsTransConfigService;
import com.hitrust.emv.threeds.threedsserver.core.util.JsonUtil;

/**
 * 網際威信 EMV 3DS 系統 - 3DS-Server後台管理模組/3DS 交易參數設定 Controller(控制器)。
 * 
 * @author KevinWang, MiloGao
 *
 */
@SessionAttributes({ "threedsTransConfigForm" })
@Controller
public class ThreedsTransConfigController {

	private static final Logger logger = LoggerFactory.getLogger(ThreedsTransConfigController.class);
	
	/**
	 * 用戶訊息 Resource。
	 */
	@Autowired
	private MessageSource messageSource;

	/**
	 * <交易參數設定> 服務 (已實作)
	 */
	@Autowired
	private ThreedsTransConfigService configService;

	/**
	 * <系統代碼參數> 服務 (已實作)
	 */
	@Autowired
	private SysCodeService cardSchemaService;
	
	/**
	 * 服務調用之前的初始化程序。
	 * 
	 * @param model 網頁級資料模型。
	 * @param session 瀏覽器級資料模型。
	 */
	@ModelAttribute
	public void initial(Model model, HttpSession session) {
		
		// 檢查(1): 網頁綁定用表單。
		ThreedsTransConfigForm form = (ThreedsTransConfigForm)
				session.getAttribute("threedsTransConfigForm");
		
		if (form == null) {
			form = new ThreedsTransConfigForm();
			logger.info("@SessionAttributes(threedsTransConfigForm)");
		}
		
		if (model.containsAttribute("threedsTransConfigForm") == false) {
			model.addAttribute("threedsTransConfigForm", form);
			logger.info("@ModelAttribute(threedsTransConfigForm)");
			
			// 邏輯：卡組織不容易變，所以初始化時載入一次即可。
			form.setCardSchemaList(cardSchemaService.
					findByCodeTypeOrderByCodeOrder(SysCodeService.TYPE_CARD_SCHEME));
			logger.info("card-schema = " + form.getCardSchemaList().size());
			
			// 邏輯：交易通道的選項(文字)。
			List<String> channelEnableLabel = new ArrayList<String>();
			channelEnableLabel.add(messageSource.getMessage(
					"ui.3ds-trans-config.channel.disable", null, 
					LocaleContextHolder.getLocale()));
			channelEnableLabel.add(messageSource.getMessage(
					"ui.3ds-trans-config.channel.enable", null, 
					LocaleContextHolder.getLocale()));
			form.setChannelEnableLabel(channelEnableLabel);
		}
	}
	
	/**
	 * 修改作業 (1/2) - 訪問
	 * 
	 * @param form 網頁綁定用表單。
	 * @param model 資料模型。
	 * @return 修改作業的網頁路徑。
	 */
	@RequestMapping(path = "/3ds_trans_config/edit", method = RequestMethod.GET)
    @AcessRightCheck(accessId = "trans_argument")
	public String showEditForm(
			@ModelAttribute("threedsTransConfigForm") ThreedsTransConfigForm form,
			Model model) {

		// 1. 準備：資料模型。
		
		// (1) 取回：<卡組織> 集合。
		List<SysCode> cardSchemaList = form.getCardSchemaList();
		// (2) 查詢：當前 <交易參數設定> 集合。
		List<ThreedsTransConfig> currentConfigs = configService.findAll();
		// (3) 掃一遍，<交易參數設定>
		List<ThreedsTransConfig> entities = new ArrayList<ThreedsTransConfig>();
		for (SysCode cardSchema : cardSchemaList) {
			// 1. 比對："code_id" 欄位，V/M/J/C。
			ThreedsTransConfig entity = null;
			for (ThreedsTransConfig config : currentConfigs) {
				if (cardSchema.getCodeId().equals(config.getCardScheme())) {
					entity = config;
					break;
				}
			}
			// 2. 新卡組織：配置預設值。
			if (entity == null) {
				entity = new ThreedsTransConfig(cardSchema.getCodeId());
				try {
					configService.save(entity);
				} catch (Exception ex) {
					logger.warn(ex.toString());
				}
			}
			// 3. 加到 buffer 裡，暫時擺著。
			entities.add(entity);
		}
		// (4) "查詢結果" 加到資料模型裡面去。
		form.setEntities(entities);
		logger.info("entities = " + entities.size());
		
		// 2. 返回：修改作業的網頁路徑。
		logger.info("visit : showEditForm(count = " + entities.size() + ")");
		return "/3ds_trans_config/edit";
	}

	/**
	 * 修改作業 (2/2) - 提交。 
	 * 
	 * @param form 網頁綁定用表單。
	 * @param model 資料模型。
	 * @return 修改作業的網頁路徑。
	 */
	@RequestMapping(path = "/3ds_trans_config/edit", method = RequestMethod.POST)
    @AcessRightCheck(accessId = "trans_argument")
	@DoOperationLog(accessId = "trans_argument", operation = "E" , targetObject = "T_THREEDS_TRANS_CONFIG")
	public String edit(
			@ModelAttribute("threedsTransConfigForm") ThreedsTransConfigForm form, 
			Model model) {
		// 操作記錄 - 異動前/後資料
		try {
			//需要將list的資料轉換成map
			List<ThreedsTransConfig> data=configService.findAll();
			HashMap<String, List<ThreedsTransConfig>> dataMap=new HashMap<>();
			dataMap.put("entities", data);
			LogContextHolder.putLogAttribute(LogContextHolder.ATTR_DATA_BEFORE, JsonUtil.writeValueAsBytes(dataMap));
			LogContextHolder.putLogAttribute(LogContextHolder.ATTR_DATA_AFTER,JsonUtil.writeValueAsBytes(form));
		} catch (JsonProcessingException e) {
			logger.warn("ThreedsTransConfig write before log error");
		}
		
		
		
		// 1. 更新：設定值。
		for (ThreedsTransConfig config : form.getEntities()) {
			try {
				configService.update(config);
			} catch (ResourceNotFoundException ex) {
				model.addAttribute(WebKeyConst.ERRORS, messageSource.getMessage(
						"warn.resource-not-exist", null, 
						LocaleContextHolder.getLocale()));
				logger.warn("error : edit(" + config.getOid() + ")");
				return "/3ds_trans_config/edit";
			}
		}
		
		// 2. 返回：查詢作業路徑。
		logger.info("success : edit(count = " + form.getEntities().size() + ")");
		model.addAttribute(WebKeyConst.SUCCESS_MSG, messageSource.getMessage(
				"ui.successfully.modified", null, 
				LocaleContextHolder.getLocale()));
		
		// 操作記錄 - 操作結果
		LogContextHolder.putLogAttribute(LogContextHolder.ATTR_RESULT,true);
		return "/3ds_trans_config/edit";
	}
}
