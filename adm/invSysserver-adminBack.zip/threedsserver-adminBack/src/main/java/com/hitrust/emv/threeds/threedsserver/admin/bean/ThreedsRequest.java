//package com.hitrust.emv.threeds.threedsserver.core.base.bean;
package com.hitrust.emv.threeds.threedsserver.admin.bean;

import com.hitrust.emv.threeds.threedsserver.core.bean.BaseBean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Lob;
import javax.persistence.Table;

@Entity
@Table(name = "T_I_THREEDS_REQUEST")
public class ThreedsRequest extends BaseBean {

	private static final long serialVersionUID = 1L;

	/**
	 * 請求處理狀態
	 */
	@Column(name = "STATUS",length = 2)
	private String status;

	/**
	 * 請求來源數據
	 */
	@Lob
	@Column(name = "ORI_DATA", length = 9999, nullable = true)
	private String origData;

	/**
	 * 用戶端模式
	 */
	@Column(name = "CLIENT_MODE",length = 1)
	private String clientMode;

	/**
	 * 3DS Requester通知接收URL
	 */
	@Column(name = "NOTIFICATION_URL",length = 256)
	private String notificationURL;

	/**
	 * 3DS Requester是否接收驗證結果數據
	 */
	@Column(name = "ENABLE_RESULT",length = 1)
	private String enableResult;

	/**
	 * 是否須執行3DS Method
	 */
	@Column(name = "ENABLE_METHOD",length = 1)
	private String enableMethod;

	/**
	 * 3DS Server交易序號
	 */
	@Column(name = "THREEDS_SERVER_TRANS_ID",length = 36)
	private String threeDSServerTransID;

	/**
	 * 3DS Method執行結果標記
	 */
	@Column(name = "THREEDS_COMP_IND",length = 1)
	private String threeDSCompInd;

	/**
	 * ACS版本號
	 */
	@Column(name = "ACS_VERSION",length = 8)
	private String acsVersion;

	/**
	 * 是否停用3DS 2.0 Challenge機制
	 */
	@Column(name = "DISABLE_CHALLENGE",length = 1)
	private String disableChallenge;

    /**
     * 3DS Requestor端交易訂單序號
     */
    @Column(name = "THREEDS_REQUESTOR_ORDER_ID",length = 35)
    private String threeDSRequestorOrderID;

    /**
     * 3DS DS列管的Requestor識別碼
     */
    @Column(name = "THREEDS_REQUESTOR_ID",length = 35)
    private String threeDSRequestorID;

    /**
     * 3DS Integrator列管的Requestor帳號
     */
    @Column(name = "INTEGRATOR_REQUESTOR_ID",length = 36)
    private String integratorRequestorID;

    /**
     * 3DS Acquirer編列的商戶識別碼
     */
    @Column(name = "MERCHANT_ID",length = 35)
    private String merchantID;

	public ThreedsRequest() {
		super();
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getOrigData() {
		return origData;
	}

	public void setOrigData(String origData) {
		this.origData = origData;
	}

	public String getClientMode() {
		return clientMode;
	}

	public void setClientMode(String clientMode) {
		this.clientMode = clientMode;
	}

	public String getNotificationURL() {
		return notificationURL;
	}

	public void setNotificationURL(String notificationURL) {
		this.notificationURL = notificationURL;
	}

	public String getEnableResult() {
		return enableResult;
	}

	public void setEnableResult(String enableResult) {
		this.enableResult = enableResult;
	}

	public String getEnableMethod() {
		return enableMethod;
	}

	public void setEnableMethod(String enableMethod) {
		this.enableMethod = enableMethod;
	}

	public String getThreeDSServerTransID() {
		return threeDSServerTransID;
	}

	public void setThreeDSServerTransID(String threeDSServerTransID) {
		this.threeDSServerTransID = threeDSServerTransID;
	}

	public String getThreeDSCompInd() {
		return threeDSCompInd;
	}

	public void setThreeDSCompInd(String threeDSCompInd) {
		this.threeDSCompInd = threeDSCompInd;
	}

	public String getAcsVersion() {
		return acsVersion;
	}

	public void setAcsVersion(String acsVersion) {
		this.acsVersion = acsVersion;
	}

	public String getDisableChallenge() {
		return disableChallenge;
	}

	public void setDisableChallenge(String disableChallenge) {
		this.disableChallenge = disableChallenge;
	}

    public String getThreeDSRequestorOrderID() {
        return threeDSRequestorOrderID;
    }

    public void setThreeDSRequestorOrderID(String threeDSRequestorOrderID) {
        this.threeDSRequestorOrderID = threeDSRequestorOrderID;
    }

    public String getThreeDSRequestorID() {
        return threeDSRequestorID;
    }

    public void setThreeDSRequestorID(String threeDSRequestorID) {
        this.threeDSRequestorID = threeDSRequestorID;
    }

    public String getIntegratorRequestorID() {
        return integratorRequestorID;
    }

    public void setIntegratorRequestorID(String integratorRequestorID) {
        this.integratorRequestorID = integratorRequestorID;
    }

    public String getMerchantID() {
        return merchantID;
    }

    public void setMerchantID(String merchantID) {
        this.merchantID = merchantID;
    }
}
