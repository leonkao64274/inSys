/*
 * @(#)ThreedsTransConfigController.java
 *
 * Copyright (c) 2017 HiTRUST Incorporated.
 * All rights reserved.
 * 
 * Description:
 *      網際威信 EMV 3DS 系統 - 3DS-Server後台管理模組/3DS 交易參數設定 Form (綁定表單)。
 *
 * Modify History:
 * v1.00, 2017/07/11, Kevin Wang
 *   1) First release
 * v1.00, 2017/08/01, Milo Gao
 *   2) 接手開發。
 */
package com.hitrust.emv.threeds.threedsserver.admin.controller;

import java.io.Serializable;
import java.util.List;
import com.hitrust.emv.threeds.threedsserver.core.bean.SysCode;
import com.hitrust.emv.threeds.threedsserver.core.bean.ThreedsTransConfig;

/**
 * 網際威信 EMV 3DS 系統 - 3DS-Server後台管理模組/3DS 交易參數設定 Form (綁定表單)。
 * 
 * @author KevinWang, MiloGao
 */
public class ThreedsTransConfigForm implements Serializable{
	
	private static final long serialVersionUID = 1L;

	/**
	 * 組態屬性(1): <卡組織> 集合。
	 */
	private List<SysCode> cardSchemaList;
	
	/**
	 * 組態屬性(2): 交易通道的I18N文字。
	 */
	private List<String> channelEnableLabel;
		
	/**
	 * 資料屬性(1): <交易參數設定> 集合。
	 */
	private List<ThreedsTransConfig> entities;
	
    //=================================================
    // constructors
    //=================================================

    /**
     * 預設建構子
     */
	public ThreedsTransConfigForm() {}

    //=================================================
    // getter & setter
    //=================================================

	public List<SysCode> getCardSchemaList() {
		return cardSchemaList;
	}

	public void setCardSchemaList(List<SysCode> cardSchemaList) {
		this.cardSchemaList = cardSchemaList;
	}

	public List<String> getChannelEnableLabel() {
		return channelEnableLabel;
	}

	public void setChannelEnableLabel(List<String> channelEnableLabel) {
		this.channelEnableLabel = channelEnableLabel;
	}

	public List<ThreedsTransConfig> getEntities() {
		return entities;
	}

	public void setEntities(List<ThreedsTransConfig> entities) {
		this.entities = entities;
	}	
}
