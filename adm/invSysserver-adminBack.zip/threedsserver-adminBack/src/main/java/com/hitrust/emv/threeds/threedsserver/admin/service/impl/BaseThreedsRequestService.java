//package com.hitrust.emv.threeds.threedsserver.core.base.service.impl;
package com.hitrust.emv.threeds.threedsserver.admin.service.impl;

//import com.hitrust.emv.threeds.threedsserver.core.base.bean.ThreedsRequest;
//import com.hitrust.emv.threeds.threedsserver.core.base.dao.ThreedsRequestDao;
//import com.hitrust.emv.threeds.threedsserver.core.base.enums.ThreeDSData;
//import com.hitrust.emv.threeds.threedsserver.core.base.exception.ThreeDSDataNotFoundException;
//import com.hitrust.emv.threeds.threedsserver.core.base.service.ThreedsRequestService;
//import com.hitrust.emv.threeds.threedsserver.core.base.util.DateTimeUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.hitrust.emv.threeds.threedsserver.admin.bean.ThreedsRequest;

import com.hitrust.emv.threeds.threedsserver.admin.controller.ThreeDSData;

import com.hitrust.emv.threeds.threedsserver.admin.dao.ThreedsRequestDao;
import com.hitrust.emv.threeds.threedsserver.admin.exception.ThreeDSDataNotFoundException;
import com.hitrust.emv.threeds.threedsserver.admin.service.ThreedsRequestService;
import com.hitrust.emv.threeds.threedsserver.admin.util.DateTimeUtil;

import java.util.NoSuchElementException;

@Service
@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED, readOnly = true, rollbackFor = {Exception.class})
public class BaseThreedsRequestService implements ThreedsRequestService {

	private static final Logger logger = LoggerFactory.getLogger(BaseThreedsRequestService.class);

	@Autowired
	private ThreedsRequestDao threedsRequestDao;

	@Override
	@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED, readOnly = false, rollbackFor = {Exception.class})
	public <S extends ThreedsRequest> void save(S s) {
		// 設定資料建立、異動時間
		s.setCreateDate(DateTimeUtil.getCurrentDate());
		s.setCreateTime(DateTimeUtil.getCurrentTime());
		s.setUpdateDate(DateTimeUtil.getCurrentDate());
		s.setUpdateTime(DateTimeUtil.getCurrentTime());
		// 新增資料數據
		this.threedsRequestDao.save(s);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED, readOnly = false, rollbackFor = {Exception.class})
	public <S extends ThreedsRequest> void update(S s) {
		// 設定資料異動時間
		s.setUpdateDate(DateTimeUtil.getCurrentDate());
		s.setUpdateTime(DateTimeUtil.getCurrentTime());
		// 更新資料數據
		this.threedsRequestDao.save(s);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED, readOnly = false, rollbackFor = {Exception.class})
	public void delete(Long id) {
		// 依據主鍵值刪除資料數據
		this.threedsRequestDao.delete(id);
	}

	@Override
	public ThreedsRequest findById(Long id) {
		// 依據主鍵值查詢資料數據
		return this.threedsRequestDao.findOne(id);
	}

	@Override
	public ThreedsRequest findByThreeDSServerTransID(String threeDSServerTransID) throws ThreeDSDataNotFoundException {
		ThreedsRequest threedsRequest = null;
		try {
			threedsRequest = this.threedsRequestDao.findByThreeDSServerTransID(threeDSServerTransID);

		} catch (Exception e) {
			logger.error("exception when finding threedsRequest by threeDSServerTransId", e);
			throw new ThreeDSDataNotFoundException(ThreeDSData.THREEDS_REQUEST);
		}

		// 查無對應資料時回傳null
		if (threedsRequest == null) {
			logger.debug("threedsRequest not found by threeDSServerTransId = " + threeDSServerTransID);
			throw new ThreeDSDataNotFoundException("threedsRequest not found by threeDSServerTransId", ThreeDSData.THREEDS_REQUEST);
		}

		return threedsRequest;
	}

	@Override
	public ThreedsRequest findByOid(String oid) throws ThreeDSDataNotFoundException {
		ThreedsRequest threedsRequest;
		try {
			Long id = Long.parseLong(oid);
			threedsRequest = this.threedsRequestDao.findOne(id);

		} catch (IllegalArgumentException | NoSuchElementException e) {
			/*
			 * NumberFormatException: oid is parsed long failed.
			 * IllegalArgumentException: id is null.
			 * NoSuchElementException: threedsRequest not exists.
			 */
			logger.error("exception when finding threedsRequest by oid string: " + e.getClass().getName());
			throw new ThreeDSDataNotFoundException(ThreeDSData.THREEDS_REQUEST);
		}

		return threedsRequest;
	}

}
