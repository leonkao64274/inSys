//package com.hitrust.emv.threeds.threedsserver.core.base.service.impl;
package com.hitrust.emv.threeds.threedsserver.admin.service.impl;

import java.util.List;
import java.util.NoSuchElementException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.hitrust.emv.threeds.threedsserver.admin.bean.VThreedsTransMerge;
import com.hitrust.emv.threeds.threedsserver.admin.controller.ThreeDSData;
import com.hitrust.emv.threeds.threedsserver.admin.dao.VThreedsTransMergeDao;
import com.hitrust.emv.threeds.threedsserver.admin.exception.ThreeDSDataNotFoundException;
import com.hitrust.emv.threeds.threedsserver.admin.service.VThreedsTransMergeService;
import com.hitrust.emv.threeds.threedsserver.admin.util.DateTimeUtil;

//import com.hitrust.emv.threeds.threedsserver.core.base.bean.VThreedsTransMerge;
//import com.hitrust.emv.threeds.threedsserver.core.base.dao.VThreedsTransMergeDao;
//import com.hitrust.emv.threeds.threedsserver.core.base.enums.ThreeDSData;
//import com.hitrust.emv.threeds.threedsserver.core.base.exception.ThreeDSDataNotFoundException;
//import com.hitrust.emv.threeds.threedsserver.core.base.service.VThreedsTransMergeService;
//import com.hitrust.emv.threeds.threedsserver.core.base.util.DateTimeUtil;

@Service
@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED, readOnly = true, rollbackFor = {Exception.class})
public class BaseVThreedsTransMergeService implements VThreedsTransMergeService {

	private static final Logger logger = LoggerFactory.getLogger(BaseVThreedsTransMergeService.class);

	@Autowired
	private VThreedsTransMergeDao vThreedsTransMergeDao;

	@Override
	@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED, readOnly = false, rollbackFor = {Exception.class})
	public <S extends VThreedsTransMerge> void save(S s) {
		// 設定資料建立、異動時間
		s.setCreateDate(DateTimeUtil.getCurrentDate());
		s.setCreateTime(DateTimeUtil.getCurrentTime());
		s.setUpdateDate(DateTimeUtil.getCurrentDate());
		s.setUpdateTime(DateTimeUtil.getCurrentTime());
		// 新增資料數據
		this.vThreedsTransMergeDao.save(s);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED, readOnly = false, rollbackFor = {Exception.class})
	public <S extends VThreedsTransMerge> void update(S s) {
		// 設定資料異動時間
		s.setUpdateDate(DateTimeUtil.getCurrentDate());
		s.setUpdateTime(DateTimeUtil.getCurrentTime());
		// 更新資料數據
		this.vThreedsTransMergeDao.save(s);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED, readOnly = false, rollbackFor = {Exception.class})
	public void delete(Long id) {
		// 依據主鍵值刪除資料數據
		this.vThreedsTransMergeDao.delete(id);
	}

	@Override
	public VThreedsTransMerge findById(Long id) {
		// 依據主鍵值查詢資料數據
		return this.vThreedsTransMergeDao.findOne(id);
	}

	@Override
	public VThreedsTransMerge findByThreeDSServerTransId(String threeDSServerTransID) throws ThreeDSDataNotFoundException {
		VThreedsTransMerge VThreedsTransMerge = null;
		try {
			VThreedsTransMerge = this.vThreedsTransMergeDao.findByThreeDSServerTransId(threeDSServerTransID);

		} catch (Exception e) {
			logger.error("exception when finding VThreedsTransMerge by threeDSServerTransId", e);
			throw new ThreeDSDataNotFoundException(ThreeDSData.THREEDS_REQUEST);
		}

		// 查無對應資料時回傳null
		if (VThreedsTransMerge == null) {
			logger.debug("VThreedsTransMerge not found by threeDSServerTransId = " + threeDSServerTransID);
			throw new ThreeDSDataNotFoundException("VThreedsTransMerge not found by threeDSServerTransId", ThreeDSData.THREEDS_REQUEST);
		}

		return VThreedsTransMerge;
	}

	@Override
	public VThreedsTransMerge findByOid(String oid) throws ThreeDSDataNotFoundException {
		VThreedsTransMerge VThreedsTransMerge;
		try {
			Long id = Long.parseLong(oid);
			VThreedsTransMerge = this.vThreedsTransMergeDao.findOne(id);

		} catch (IllegalArgumentException | NoSuchElementException e) {
			/*
			 * NumberFormatException: oid is parsed long failed.
			 * IllegalArgumentException: id is null.
			 * NoSuchElementException: VThreedsTransMerge not exists.
			 */
			logger.error("exception when finding VThreedsTransMerge by oid string: " + e.getClass().getName());
			throw new ThreeDSDataNotFoundException(ThreeDSData.THREEDS_REQUEST);
		}

		return VThreedsTransMerge;
	}

    @Override
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED, readOnly = false, rollbackFor = {Exception.class})
    public Page<VThreedsTransMerge> findByCriteria(
        String createDateStart, String createDateEnd, String cardScheme, String messageVersion,
        String acsTransID, String threeDSServerTransID, String transStatus, String acctID,
        String acctNumberPrefix, String acctNumberPostfix, String acquirerMerchantID, String deviceChannel,
        String messageCategory, String purchaseAmount,
        String integratorRequestorId, String threedsRequestorOrderId, Pageable pageable) {
        //查询总表的数据
        Page<VThreedsTransMerge> queryResult = vThreedsTransMergeDao.findByCriteria(
                createDateStart, createDateEnd, cardScheme, messageVersion,
                acsTransID, threeDSServerTransID, transStatus, acctID,
                acctNumberPrefix, acctNumberPostfix, acquirerMerchantID, deviceChannel,
                messageCategory, purchaseAmount, integratorRequestorId,
                threedsRequestorOrderId, pageable);

        return queryResult;
    }
    
    @Transactional(propagation = Propagation.REQUIRED, isolation = Isolation.READ_COMMITTED, readOnly = false, rollbackFor = {Exception.class})
    public List<VThreedsTransMerge> findAll(){
    	return this.vThreedsTransMergeDao.findAll();
    }
    

}
