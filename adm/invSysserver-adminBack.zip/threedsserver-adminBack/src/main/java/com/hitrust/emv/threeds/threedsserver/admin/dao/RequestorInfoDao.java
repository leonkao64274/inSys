/*
 * @(#)DirectoryServerDao.java
 *
 * Copyright (c) 2020 HiTRUST Incorporated.
 * All rights reserved.
 * 
 * Description:
 *      網際威信 EMV 3DS 系統 - 商店服務器設定 DAO 介面
 *
 * Modify History:
 * v1.00, 2020/07/16
 *   1) First release
 *
 */
package com.hitrust.emv.threeds.threedsserver.admin.dao;
//package com.hitrust.emv.threeds.threedsserver.core.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;

import com.hitrust.emv.threeds.threedsserver.admin.bean.MerchantInfo;
import com.hitrust.emv.threeds.threedsserver.admin.bean.RequestorInfo;

//import com.hitrust.emv.threeds.threedsserver.core.bean.MerchantInfo;

/**
 * 網際威信 EMV 3DS 系統 - 目錄服務器設定 DAO 介面
 * 對應至資料庫 T_MERCHANT_INFO 表的新增、修改、刪除及查詢相關操作
 * 
 * @author
 */
public interface RequestorInfoDao extends CrudRepository<RequestorInfo, Long> , QueryByExampleExecutor<RequestorInfo> {
    
    /**
     * @param requestor's ID  
     * @return requestor's information
     */
    public RequestorInfo findByRequestorId(String requestorId);
    
    
    /**
     * @param requestor's name 
     * @return requestor's information
     */
    
    public MerchantInfo findByRequestorName(String requestorName);
    

    /**
     * @param requestor's name 
     * @param requestor's ID  
     * @return requestor's information
     */
    public MerchantInfo findByRequestorNameAndRequestorId(String requestorName, String requestorId);



}
