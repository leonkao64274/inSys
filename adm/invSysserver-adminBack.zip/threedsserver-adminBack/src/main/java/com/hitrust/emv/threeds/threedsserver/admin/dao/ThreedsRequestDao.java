//package com.hitrust.emv.threeds.threedsserver.core.base.dao;
package com.hitrust.emv.threeds.threedsserver.admin.dao;

//import com.hitrust.emv.threeds.threedsserver.core.base.bean.ThreedsRequest;
import org.springframework.data.jpa.repository.JpaRepository;

import com.hitrust.emv.threeds.threedsserver.admin.bean.ThreedsRequest;

public interface ThreedsRequestDao extends JpaRepository<ThreedsRequest, Long> {

	/**
	 * 依據3DS Server交易序號查詢對應的3DS驗證請求資料
	 *
	 * @param threeDSServerTransID 3DS Server交易序號
	 * @return 對應的3DS驗證請求資料
	 */
	public ThreedsRequest findByThreeDSServerTransID(String threeDSServerTransID);

}
