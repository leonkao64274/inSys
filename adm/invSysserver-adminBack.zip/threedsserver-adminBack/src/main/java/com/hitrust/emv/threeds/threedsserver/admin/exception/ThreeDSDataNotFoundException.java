//package com.hitrust.emv.threeds.threedsserver.core.base.exception;
package com.hitrust.emv.threeds.threedsserver.admin.exception;

import com.hitrust.emv.threeds.threedsserver.admin.controller.Errors;
import com.hitrust.emv.threeds.threedsserver.admin.controller.ThreeDSData;

//import com.hitrust.emv.threeds.threedsserver.core.base.enums.Errors;
//import com.hitrust.emv.threeds.threedsserver.core.base.enums.ThreeDSData;

public class ThreeDSDataNotFoundException extends BaseException {

	private static final long serialVersionUID = 1L;

	private ThreeDSData dataType;

	public ThreeDSDataNotFoundException() {
		super(Errors.THREEDS_DATA_NOT_FOUND.getCode(), Errors.THREEDS_DATA_NOT_FOUND.getMessage());
	}

	public ThreeDSDataNotFoundException(ThreeDSData dataType) {
		super(Errors.THREEDS_DATA_NOT_FOUND.getCode(), Errors.THREEDS_DATA_NOT_FOUND.getMessage());
		this.dataType = dataType;
	}

	public ThreeDSDataNotFoundException(String errorMessage, ThreeDSData dataType) {
		super(Errors.THREEDS_DATA_NOT_FOUND.getCode(), errorMessage);
		this.dataType = dataType;
	}

	public ThreeDSData getDataType() {
		return dataType;
	}

	public void setDataType(ThreeDSData dataType) {
		this.dataType = dataType;
	}

}
