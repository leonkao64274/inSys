/*
 * @(#)HttpClientUtility.java
 *
 * Copyright (c) 2017 HiTRUST Incorporated.
 * All rights reserved.
 * 
 * Description:
 *      網際威信 EMV 3DS 系統 - 3DS Server 後台管理系統 HttpClient 工具類別
 *
 * Modify History:
 * v1.00, 2018/01/11, AlexYang
 *   1) First release
 *
 */
package com.hitrust.emv.threeds.threedsserver.admin.util;

import org.apache.http.client.config.RequestConfig;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;

/**
*
* @author AlexYang
*/
public class HttpClientUtility {
   
   public static ClientHttpRequestFactory getClientHttpRequestFactory() {
       //int timeout = 30 * 1000;
       int timeout = 5 * 1000;
       RequestConfig config = RequestConfig.custom()
               .setConnectTimeout(timeout)
               .setConnectionRequestTimeout(timeout)
               .setSocketTimeout(timeout)
               .build();
       
       CloseableHttpClient client = HttpClientBuilder
               .create()
               .setDefaultRequestConfig(config)
               .build();
       
       HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(client);
       requestFactory.setConnectTimeout(timeout);
       //requestFactory.setConnectionRequestTimeout(timeout);
       requestFactory.setReadTimeout(timeout);
       //return new HttpComponentsClientHttpRequestFactory(client);
       return requestFactory;
   }
   
}
