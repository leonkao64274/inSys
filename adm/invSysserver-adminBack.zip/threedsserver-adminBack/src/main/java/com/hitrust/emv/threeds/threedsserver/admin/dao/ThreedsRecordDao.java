//package com.hitrust.emv.threeds.threedsserver.core.base.dao;
package com.hitrust.emv.threeds.threedsserver.admin.dao;

//import com.hitrust.emv.threeds.threedsserver.core.base.bean.ThreedsRecord;
import org.springframework.data.jpa.repository.JpaRepository;

import com.hitrust.emv.threeds.threedsserver.admin.bean.ThreedsRecord;

public interface ThreedsRecordDao extends JpaRepository<ThreedsRecord, Long> {

	/**
	 * 依據3DS交易序號查詢對應的3DS 1.0驗證交易資料
	 *
	 * @param threeDSTransID 3DS交易序號
	 * @return 對應的3DS 1.0驗證交易資料
	 */
	public ThreedsRecord findByThreeDSTransID(String threeDSTransID);

}
