//package com.hitrust.emv.threeds.threedsserver.core.base.dao;
package com.hitrust.emv.threeds.threedsserver.admin.dao;

//import com.hitrust.emv.threeds.threedsserver.core.base.bean.VThreedsTransMerge;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.hitrust.emv.threeds.threedsserver.admin.bean.VThreedsTransMerge;

public interface VThreedsTransMergeDao extends JpaRepository<VThreedsTransMerge, Long> {

	/**
	 * 依據3DS Server交易序號查詢對應的3DS驗證請求資料
	 *
	 * @param threeDSServerTransID 3DS Server交易序號
	 * @return 對應的3DS驗證請求資料
	 */
	public VThreedsTransMerge findByThreeDSServerTransId(String threeDSServerTransID);

    /**
     *
     * @Description: 根据条件查询
     *
     * @auther: liuhao
     * @date: 13:51 2020/6/15
     * @param: [createDateStart, createDateEnd, cardScheme, messageVersion, acsTransID, threeDSServerTransID, transStatus, acctID, acctNumberPrefix, acctNumberPostfix, acquirerMerchantID, deviceChannel, messageCategory, purchaseAmount, integratorRequestorId, threedsRequestorOrderId, pageable]
     * @return: org.springframework.data.domain.Page<com.hitrust.emv.threeds.threedsserver.core.base.bean.ThreedsRequest>
     *
     */
    @Query("select v from VThreedsTransMerge v " +
            " where (:createDateStart      is null or v.createDate >= :createDateStart)  " +
            "and (:createDateEnd        is null or v.createDate <= :createDateEnd)   " +
            "and (:cardScheme           is null or v.cardScheme = :cardScheme) " +
            "and (:messageVersion       is null or v.messageVersion = :messageVersion)   " +
            "and (:acsTransID           is null or v.acsTransId = :acsTransID)   " +
            "and (:threeDSServerTransID is null or v.threeDSServerTransId = :threeDSServerTransID)   " +
            "and (:transStatus          is null or v.transStatus = :transStatus)   " +
            "and (:acctID               is null or v.acctId = :acctID) " +
            "and (:acctNumberPrefix     is null or v.acctNumberPrefix = :acctNumberPrefix)  " +
            "and (:acctNumberPostfix    is null or v.acctNumberPostfix = :acctNumberPostfix)   " +
            "and (:acquirerMerchantID   is null or v.acquirerMerchantId = :acquirerMerchantID)   " +
            "and (:deviceChannel        is null or v.deviceChannel = :deviceChannel)   " +
            "and (:messageCategory      is null or v.messageCategory = :messageCategory)   " +
            "and (:purchaseAmount       is null or v.purchaseAmount = :purchaseAmount) " +
//    		"and (:integratorRequestorId       is null  )  " +
//    		"and (:threedsRequestorOrderId       is null)  "


			"and (:integratorRequestorId   is null or v.integratorRequestorId like %:integratorRequestorId%) " +
			"and (:threedsRequestorOrderId   is null or v.requestorOrderId like %:threedsRequestorOrderId%) "

//            "and (:integratorRequestorId   is null or v.integratorRequestorId like concat('%',:integratorRequestorId)) " +
//            "and (:threedsRequestorOrderId   is null or v.requestorOrderId like concat(:threedsRequestorOrderId)) "

	)
    public Page<VThreedsTransMerge> findByCriteria( 
            @Param("createDateStart") String createDateStart,
            @Param("createDateEnd") String createDateEnd,
            @Param("cardScheme") String cardScheme,
            @Param("messageVersion") String messageVersion,
            @Param("acsTransID") String acsTransID,
            @Param("threeDSServerTransID") String threeDSServerTransID,
            @Param("transStatus") String transStatus,
            @Param("acctID") String acctID,
            @Param("acctNumberPrefix") String acctNumberPrefix,
            @Param("acctNumberPostfix") String acctNumberPostfix,
            @Param("acquirerMerchantID") String acquirerMerchantID,
            @Param("deviceChannel") String deviceChannel,
            @Param("messageCategory") String messageCategory,
            @Param("purchaseAmount") String purchaseAmount,
            @Param("integratorRequestorId") String integratorRequestorId,
            @Param("threedsRequestorOrderId") String threedsRequestorOrderId,
            Pageable pageable);
}
