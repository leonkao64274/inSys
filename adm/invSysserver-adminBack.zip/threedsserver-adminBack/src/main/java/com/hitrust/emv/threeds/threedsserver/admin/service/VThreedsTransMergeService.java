//package com.hitrust.emv.threeds.threedsserver.core.base.service;
package com.hitrust.emv.threeds.threedsserver.admin.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.hitrust.emv.threeds.threedsserver.admin.bean.VThreedsTransMerge;
import com.hitrust.emv.threeds.threedsserver.admin.exception.ThreeDSDataNotFoundException;
//import com.hitrust.emv.threeds.threedsserver.core.base.bean.VThreedsTransMerge;
//import com.hitrust.emv.threeds.threedsserver.core.base.exception.ThreeDSDataNotFoundException;
import com.hitrust.emv.threeds.threedsserver.core.service.GenericEntityService;

public interface VThreedsTransMergeService extends GenericEntityService<VThreedsTransMerge, Long> {

	/**
	 * 依據3DS Server交易序號查詢對應的3DS驗證請求資料
	 *
	 * @param threeDSServerTransID 3DS Server交易序號
	 * @return 對應的3DS驗證請求資料
	 * @throws ThreeDSDataNotFoundException 無法取得對應資料時拋出
	 */
	public VThreedsTransMerge findByThreeDSServerTransId(String threeDSServerTransID) throws ThreeDSDataNotFoundException;

	/**
	 * 依據oid值字串查詢對應的3DS驗證請求資料
	 *
	 * @param oid oid字串
	 * @return 對應的3DS驗證請求資料
	 * @throws ThreeDSDataNotFoundException 無法取得對應資料時拋出
	 */
	public VThreedsTransMerge findByOid(String oid) throws ThreeDSDataNotFoundException;


	/**
	 *
	 * @Description: 查询交易信息
	 *
	 * @auther: liuhao
	 * @date: 13:47 2020/6/15
	 * @param: [var1, var2, var3, var4, var5, var6, var7, var8, var9, var10, var11, var12, var13, var14, var15, var16, var17]
	 * @return: org.springframework.data.domain.Page<com.hitrust.emv.threeds.threedsserver.core.base.bean.ThreedsRequest>
	 *
	 */
    Page<VThreedsTransMerge> findByCriteria(String var1, String var2, String var3, String var4, String var5, String var6, String var7, String var8, String var9, String var10, String var11, String var12, String var13, String var14, String var15, String var16, Pageable var17);
    
    List<VThreedsTransMerge> findAll();
    
}
