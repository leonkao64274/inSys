/*
 * @(#)ThreedsServerCertForm.java
 *
 * Copyright (c) 2017 HiTRUST Incorporated.
 * All rights reserved.
 * 
 * Description:
 *      網際威信 EMV 3DS 系統 - 3ds 後台管理系統 "DS憑證資訊" 載入作業表單類別
 *
 * Modify History:
 * v1.00, 2018/04/02, BOB
 *   1) First release
 *
 */
package com.hitrust.emv.threeds.threedsserver.admin.controller;

import com.hitrust.emv.threeds.threedsserver.core.bean.ThreedsServerCert;

public class ThreedsServerCertForm extends ThreedsServerCert{

	private static final long serialVersionUID = 1L;
	
	private int certEncode;

	public int getCertEncode() {
		return certEncode;
	}

	public void setCertEncode(int certEncode) {
		this.certEncode = certEncode;
	}
}
