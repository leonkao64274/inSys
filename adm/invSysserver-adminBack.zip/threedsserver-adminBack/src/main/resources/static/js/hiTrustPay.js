//選擇日期
function selectDate(vId){
	alert("123");
	$('#'+vId).datepicker({
		format: 'yyyy/mm/dd'
	 });
}